package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static sample.LibPalabrasReservadas.validarPalabra;
import static sample.LibPalabrasReservadas.regresarSignificado;
import static sample.LibSimbolos.*;
import static sample.ValueDefinitionsVariable.*;


public class Controller implements Initializable {
    String exitErr;

    @FXML private TextArea entrada;
    @FXML private TextArea exitData;
    @FXML private TableView<dataTable> table;
    @FXML private TableColumn<dataTable, String> dataColum;
    @FXML private TableColumn<dataTable, String> definicionColum;

    ObservableList<dataTable> arguments = FXCollections.observableArrayList();


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        dataColum.setCellValueFactory(new PropertyValueFactory<dataTable, String>("valor"));
        definicionColum.setCellValueFactory(new PropertyValueFactory<dataTable, String>("definicion"));

        table.setItems(arguments);
    }


    @FXML
    public void analizador() {
        arguments.clear();
        exitErr = null;
        exitData.setText(" ");
        String oracion = entrada.getText();
        String dataAux = entrada.getText();
        List<String> matchList = new ArrayList<String>();
        Pattern regex = Pattern.compile("[^\\s\"']+|\"[^\"]*\"|'[^']*'");
        Matcher regexMatcher = regex.matcher(oracion);
        int contador = 1;
        while (regexMatcher.find()) {

            String cadena = regexMatcher.group();
            String originalData = cadena;

            if (validarPalabra(cadena)){

                cadena = regresarSignificado(cadena);

            } else if (validarSimbolo(cadena)) {

                cadena = regresarDefincion(cadena);

            } else if (simbolosNoPermitidos(cadena)) {

                cadena = "Simbolo no permitido";
                exitErr += "ERR: en posición (" + contador + ") con valor de \""  + originalData + "\" | y error: " + cadena + "\n";

            } else if (simbolosComparativos(cadena)) {

                cadena = regresarSignificado(cadena);

            } else if (verificarIdentificador(cadena)) {
                if (verificadorArgumento(cadena)) {
                    boolean access = false;
                    try {
                        Double data  = Double.parseDouble(cadena);
                        data = 0.0;
                        if (data == 0.0) {
                            cadena = "Númerico";
                            access = true;
                        }

                    } catch (Exception e) {
                        if (!access) {
                            Pattern regexAlpha = Pattern.compile("[.]|[#]|[!]|[$]|[%]|[*]|[+]|[?]|[~]|[`]|[}]|[{]|[,]|[>]|[<]|[&]|[|]|[]]|[@]|^]|[¡]");
                            Matcher regexData = regexAlpha.matcher(cadena);
                            if (regexData.find() && cadena.charAt(0) != '\"') {
                                cadena = "Error, no permitible conjugación de simbolos - palabras";
                                exitErr += "ERR: en posición (" + contador + ") con valor de \""  + originalData + "\" | y error: " + cadena + "\n";
                            } else {
                                cadena = "Texto";
                            }
                        }
                    }

                } else {
                    System.out.println(cadena);
                    cadena = "Identificador inválido";
                    exitErr += "ERR: en posición (" + contador + ") con valor de \""  + originalData + "\" | y error: " + cadena + "\n";
                }

            } else if (!verificarIdentificador(cadena)) {

                cadena = "Identificador";

            }

            if(dataAux.equals("\"")) {
                cadena = regresarDefincion(cadena);
            }

            arguments.add(new dataTable(originalData, cadena));
            matchList.add(cadena);
            contador++;
        }



        if (exitErr != null) {
            exitData.setText(exitErr);
            exitData.setStyle("-fx-text-inner-color: red;");
        }

        table.setItems(arguments);

    }
}

/*

/Codigo de prueba:

body ( args ) {
	float dataValue = 055 ;
	args dataString = "a" ;

	if ( dataString == dataValue ) {
		displayView ( "SI" ) ;
	}  else {
		displayView ( "NO" ) ;
	}
}



varName
variableConCaracteresMayorAVeinte
5nombre
nombre6
.nombre
.nombre variable
_valueData
_value%Data
dataValue%
 */